// Common functionality for all lessons
document.addEventListener('DOMContentLoaded', function() {
    // Add lesson completion tracking
    const markComplete = document.createElement('button');
    markComplete.className = 'nav-button';
    markComplete.style.marginTop = '1rem';
    markComplete.textContent = 'Mark as Complete';

    const lessonContent = document.querySelector('.lesson-content');
    if (lessonContent) {
        lessonContent.appendChild(markComplete);
    }

    // Track completion status
    markComplete.addEventListener('click', function() {
        const currentPage = window.location.pathname;
        const completed = localStorage.getItem('completed') ? 
            JSON.parse(localStorage.getItem('completed')) : [];
        
        if (!completed.includes(currentPage)) {
            completed.push(currentPage);
            localStorage.setItem('completed', JSON.stringify(completed));
            markComplete.textContent = 'Completed!';
            markComplete.style.backgroundColor = '#059669';
        }
    });

    // Check if lesson is already completed
    const currentPage = window.location.pathname;
    const completed = localStorage.getItem('completed') ? 
        JSON.parse(localStorage.getItem('completed')) : [];
    
    if (completed.includes(currentPage)) {
        markComplete.textContent = 'Completed!';
        markComplete.style.backgroundColor = '#059669';
    }

    // Add copy functionality to code blocks
    document.querySelectorAll('pre').forEach(block => {
        const copyButton = document.createElement('button');
        copyButton.className = 'copy-button';
        copyButton.textContent = 'Copy';
        copyButton.style.position = 'absolute';
        copyButton.style.right = '1rem';
        copyButton.style.top = '0.5rem';
        copyButton.style.padding = '0.25rem 0.5rem';
        copyButton.style.background = '#2563eb';
        copyButton.style.color = 'white';
        copyButton.style.border = 'none';
        copyButton.style.borderRadius = '4px';
        copyButton.style.cursor = 'pointer';

        block.style.position = 'relative';
        block.appendChild(copyButton);

        copyButton.addEventListener('click', function() {
            navigator.clipboard.writeText(block.textContent)
                .then(() => {
                    copyButton.textContent = 'Copied!';
                    setTimeout(() => {
                        copyButton.textContent = 'Copy';
                    }, 2000);
                });
        });
    });
});